<?php

class demoData
{
    public function initData()
    {
        $return = true;
        $languages = Language::getLanguages(true);
        $id_shop = Context::getContext()->shop->id;
        $id_hook_nav = (int)$this->getIdByName('displayNav');
        $id_hook_nav1 = (int)$this->getIdByName('displayNav1');
        $id_hook_top = (int)$this->getIdByName('displayContainertop');
        $queries = [
            'INSERT INTO `'._DB_PREFIX_.'pos_staticblock` (`id_pos_staticblock`, `id_hook`, `position`, `name`,`active`) VALUES
                (1, '.$id_hook_nav.', 1, "static nav", 1),
                (2, '.$id_hook_nav1.', 2, "Links Sale", 1),
                (4, '.$id_hook_top.', 4, "Static Cms", 1),
                (5, '.$id_hook_top.', 5, "Home Banner", 1)'
        ];
        foreach (Language::getLanguages(true, Context::getContext()->shop->id) as $lang) {
            $queries[] = 'INSERT INTO `'._DB_PREFIX_.'pos_staticblock_lang` (`id_pos_staticblock`, `id_lang`, `content`) VALUES
                (1, '.(int)$lang['id_lang'].', \'<div id="_desktop_static"><div class="static-nav">We offer a 30-Day Money Back Guarantee on all purchases.</div></div>\'),
                (2, '.(int)$lang['id_lang'].', \'<div class="links_sale"><a href="prices-drop" class="big_sale"><span>Big sale Black friday</span></a></div>\'),
				(4, '.(int)$lang['id_lang'].', \'<div class="static_cms">
				<div class="col-cms">
				<div class="box_cms"><img src="/pos_antomi/img/cms/free_shipping.png" alt="" class="img-responsive" />
				<div class="txt_cms">
				<h4>Free Delivery</h4>
				<p>For all oders over $120</p>
				</div>
				</div>
				</div>
				<div class="col-cms">
				<div class="box_cms"><img src="/pos_antomi/img/cms/payment_secure.png" alt="" class="img-responsive" />
				<div class="txt_cms">
				<h4>Safe Payment</h4>
				<p>100% secure payment</p>
				</div>
				</div>
				</div>
				<div class="col-cms">
				<div class="box_cms"><img src="/pos_antomi/img/cms/returns.png" alt="" class="img-responsive" />
				<div class="txt_cms">
				<h4>Shop With Confidence</h4>
				<p>If goods have problems</p>
				</div>
				</div>
				</div>
				<div class="col-cms">
				<div class="box_cms"><img src="/pos_antomi/img/cms/support247.png" alt="" class="img-responsive" />
				<div class="txt_cms">
				<h4>24/7 Help Center</h4>
				<p>Dedicated 24/7 support</p>
				</div>
				</div>
				</div>
				<div class="col-cms">
				<div class="box_cms"><img src="/pos_antomi/img/cms/services.png" alt="" class="img-responsive" />
				<div class="txt_cms">
				<h4>Friendly Services</h4>
				<p>30 day satisfaction guarantee</p>
				</div>
				</div>
				</div>
				</div>\'),
                (5, '.(int)$lang['id_lang'].', \'<div class="home-banner">
				<div class="row row_top">
				<div class="col col1 col-xs-12">
				<div class="banner-box"><a href="#"><img src="/pos_antomi/img/cms/6_1.jpg" alt="" /></a></div>
				</div>
				<div class="col col2 col-xs-12">
				<div class="banner-box"><a href="#"><img src="/pos_antomi/img/cms/7_1.jpg" alt="" /></a></div>
				</div>
				<div class="col col3 col-xs-12">
				<div class="banner-box"><a href="#"><img src="/pos_antomi/img/cms/8_1.jpg" alt="" /></a></div>
				</div>
				</div>
				<div class="row">
				<div class="col col-lg-6 col-md-6 col-sm-12  col-xs-12">
				<div class="banner-box"><a href="#"><img src="/pos_antomi/img/cms/4_1.jpg" alt="" /></a></div>
				</div>
				<div class="col col-lg-6 col-md-6 col-sm-12  col-xs-12">
				<div class="banner-box"><a href="#"><img src="/pos_antomi/img/cms/5_1.jpg" alt="" /></a></div>
				</div>
				</div>
				</div>\')'
            ;
        }

        $queries[] = 'INSERT INTO `'._DB_PREFIX_.'pos_staticblock_shop` (`id_pos_staticblock`, `id_shop`) VALUES
                (1, 1),
                (2, 1),  
                (4, 1),
                (5, 1)'; 

        foreach ($queries as $query) {
            $return &= Db::getInstance()->execute($query);
        }

        return $return;
    }
	public function getIdByName($hook_name){
		$sql = 'SELECT h.`id_hook` FROM `'._DB_PREFIX_.'hook` h WHERE h.`name` = \''.$hook_name.'\'';
		$result = Db::getInstance()->executeS($sql);
		return $result[0]['id_hook']; 
	}
}
?>