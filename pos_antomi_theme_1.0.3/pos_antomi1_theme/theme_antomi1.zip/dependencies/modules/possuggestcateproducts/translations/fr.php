<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{postabproduct}prestashop>postabproduct_06935560825762bbb2d20a4a3ed69e4f'] = 'New Arrival';
